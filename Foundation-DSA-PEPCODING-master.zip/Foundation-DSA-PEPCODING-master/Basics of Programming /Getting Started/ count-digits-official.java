import java.util.*;

public class Main {

    public static void main(String[] args) {
        // write your code here  
        Scanner scn = new Scanner(System.in);

        int n = scn.nextInt();
        int val=0;
        while (n!=0) {
            n = n/10;
            val++;
        }

        System.out.println(val);
    }
}