package Oops.singleton;

public class main {
    public static void main(String[] args) {
        Singleton obj1 = Singleton.getInstance();
        Singleton ob2 = Singleton.getInstance();
        Singleton obj3 = Singleton.getInstance();

    }
}
