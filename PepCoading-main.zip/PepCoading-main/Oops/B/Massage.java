package Oops.B;

public class Massage {
    public static void main(String[] args) {

    }
    public  static void massage(){
        System.out.println("This is Package B");

    }
}
