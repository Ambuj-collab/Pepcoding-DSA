package LeetCode;

public class PrefixAndSuffixSearch {

    public static void main(String[] args){
        String s = "Danish";
        System.out.println(s.endsWith("Danish"));
        System.out.println(Math.pow(2,31)-1);
        System.out.println((int)1e9);


    }

}
