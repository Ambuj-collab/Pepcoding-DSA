package BinarySearchTree;
import java.util.ArrayList;
public class Test {
    public static void main(String[] args){
        System.out.print("Hello WOrld");
        ArrayList<Integer> ans = new ArrayList<>();
        for(int i = 0 ; i<=10 ; i++){
            ans.add(i);
        }
        System.out.println(ans);

    }
}
