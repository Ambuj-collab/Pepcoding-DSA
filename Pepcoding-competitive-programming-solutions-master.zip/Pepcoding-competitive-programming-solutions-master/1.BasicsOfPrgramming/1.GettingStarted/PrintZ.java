public class PrintZ {
    public static void main(String[] args) {

        // QUESTION You are required to print a 'z' of size 5 using '*'.

        System.out.println("*****");
        System.out.println("   * ");
        System.out.println("  *  ");
        System.out.println(" *   ");
        System.out.println("*****");
    }
}
