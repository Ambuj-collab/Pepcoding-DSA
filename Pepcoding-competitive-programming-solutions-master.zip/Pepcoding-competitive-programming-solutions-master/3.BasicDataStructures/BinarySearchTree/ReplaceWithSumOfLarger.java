// 1. You are given a partially written BST class.
// 2. You are required to complete the body of rwsol function. "rwsol" function is expected to replace a node's value with sum of all nodes greater than it.
// 3. Input and Output is managed for you. 

// Note -> Please watch the question video for clarity. Use the statis sum data member to complete your code.


public class ReplaceWithSumOfLarger {
    public static void main(String[] args) {
        
    }
}
