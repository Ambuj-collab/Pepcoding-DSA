package io.github.pepcoding.dynamicprogramming;

import java.util.Scanner;

public class CoinChangeCombination {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int amt = sc.nextInt();

        int[] dp = new int[amt + 1];
        dp[0] = 1;

        for (int coin : arr) {
            for (int j = coin; j < amt + 1; j++) {
                dp[j] += dp[j - coin];
            }
        }

        System.out.println(dp[amt]);
    }

}
